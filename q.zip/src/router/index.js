import Vue from 'vue'
import VueRouter from 'vue-router'
import Qing from '../views/Qing.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Qing',
    component: Qing
  }
]

const router = new VueRouter({
  routes
})

export default router
