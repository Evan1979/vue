<template>
  <div>
    <div>
      <van-nav-bar left-text="房源详情" left-arrow />
    </div>
    <div class="pic">
      <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
        <van-swipe-item><img src="../assets/8cb86f7ea243a3f126e2703505921da.jpg"></van-swipe-item>
        <van-swipe-item><img src="../assets/661895cc7e9ff280336d91e272befbd.jpg"></van-swipe-item>
        <van-swipe-item><img src="../assets/8cb86f7ea243a3f126e2703505921da.jpg"></van-swipe-item>
        <van-swipe-item><img src="../assets/661895cc7e9ff280336d91e272befbd.jpg"></van-swipe-item>
      </van-swipe>
    </div>
    <div class="wrapper">
      <div class="content">
        <div class="title">东方曼哈顿2024</div>

        <div class="money">10000元/月</div>
        <div class="tip">押二付一</div>
      </div>
      <div class="detail">
        <div class="detail_wrap"><span>118㎡</span><span>面积</span></div>
        <div class="detail_wrap"><span>3室2厅</span><span>房型</span></div>
        <div class="detail_wrap"><span>南</span><span>朝向</span></div>
      </div>
      <div class="small-detail">
        <div class="zhaungxiu"><span>装修</span><span>精装修</span></div>
        <div class="zhaungxiu"><span>楼层</span><span>高层/6层</span></div>
        <div class="zhaungxiu"><span>类型</span><span>普通住宅</span></div>
      </div>
      <div class="tap">
        <div><span style="padding:10px">近地铁</span></div>
        <div><span style="padding:10px">精装修</span></div>
        <div><span style="padding:10px">有阳台</span></div>
      </div>
    </div>
    <div class="btn">
      <van-goods-action>
        <van-goods-action-icon icon="share-o" text="分享" />
        <van-goods-action-icon icon="like-o" text="收藏" />
        <van-goods-action-button color="#ff7d29" square type="warning" text="在线聊" />
        <van-goods-action-button color="#29cd9a" square type="danger" text="租房" />
      </van-goods-action>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        images: [{
          image: '../assets/661895cc7e9ff280336d91e272befbd.jpg'
        }, {
          image: '../assets/8cb86f7ea243a3f126e2703505921da.jpg'
        }]
      }
    },
  }

</script>

<style lang="less">
  body {
    background-color: #fff;
  }

  .pic {
    width: 100%;
    height: 200px;

    .my-swipe {
      width: 100%;
      height: 100%;

      img {
        width: 100%;
        height: 100%;
      }
    }
  }

  .wrapper {
    padding: 10px 20px;

    .content {
      height: auto;

      .title {
        padding: 20px 0 10px 0;
        font-size: 20px;
        font-weight: 700;
      }

      .money {
        font-size: 22px;
        font-weight: 700;
        width: auto;
        color: orangered;
      }

      .tip {
        position: relative;
        font-size: 14px;
        color: #6b8ba4;
        margin-left: 120px;
        margin-top: -18px;
      }
    }

    .detail {
      margin: 10px auto;
      padding: 20px;
      height: auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-top: rgb(197, 197, 197) 1px solid;
      border-bottom: rgb(196, 196, 196) 1px solid;

      .detail_wrap {
        display: flex;
        justify-content: space-around;
        align-items: center;
        flex-direction: column;

        span {
          flex: 1;
        }

        span:nth-child(1) {
          font-size: 18px;
          font-weight: 700;
          margin-bottom: 5px;
        }

        span:nth-child(2) {
          font-size: 14px;
          color: rgb(163, 163, 163);
          margin-bottom: 5px;
        }
      }
    }

    .small-detail {
      overflow: hidden;

      .zhaungxiu {
        width: 50%;
        float: left;
        margin-bottom: 10px;

        span:nth-child(1) {
          font-size: 14px;
          color: rgb(163, 163, 163);
        }

        span:nth-child(2) {
          font-size: 14px;
          margin-left: 10px;
          margin-bottom: 10px;
        }
      }
    }

    .tap {
      overflow: hidden;

      div {
        float: left;
        width: auto;
        color: #409eff;
        border: 1px solid #409eff;
        margin-right: 10px;
        line-height: 25px;
        span{
            font-size: 14px;
        }
      }

    }
  }

</style>
