<template>
  <div id="app">
      <router-view ></router-view>
  </div>
</template>
<script>
  export default {

  }

</script>
<style lang='less'>
  body {
    height: 100%;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    background-color: #f4f4f4;
  }

  p {
    margin: 0;
    padding: 0;
  }

</style>
