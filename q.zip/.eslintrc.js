module.exports = {
  root: true,

  env: {
    node: true
  },

  extends: [
    'plugin:vue/essential',
    '@vue/standard'
  ],

  parserOptions: {
    parser: 'babel-eslint'
  },

  rules: {
    'no-console': 'off',
    'no-debugger': 'off',
    'space-before-function-paren': 0,
    'indent': 'off',
    'no-irregular-whitespace': 'off',
    'no-unused-vars': 0,
    'no-tabs': 'off',
    'no-trailing-spaces': 0,
    'comma-dangle': 0,
    'eqeqeq': 0,
    'semi': 0,
    'no-undef': 0,
    'prefer-const': 0

  },

  'extends': [
    'plugin:vue/essential',
    '@vue/standard'
  ]
}
